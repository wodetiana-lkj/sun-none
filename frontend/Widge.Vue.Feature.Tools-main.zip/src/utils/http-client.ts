/* eslint-disable @typescript-eslint/no-explicit-any */
import { Observable, of, switchMap } from "rxjs";
import { ajax } from "rxjs/ajax";

type HttpHeaders = Readonly<Record<string, any>>;
type HttpParams = {
  [param: string]:
    | string
    | number
    | boolean
    | ReadonlyArray<string | number | boolean>;
};

function EncodeURL(url: string, params?: HttpParams): string {
  const request_path = new URL(url);
  Object.entries(params ?? {}).forEach(([key, value]) => {
    request_path.searchParams.append(key, value.toString());
  });
  return request_path.toString();
}

class HttpClient {
  private request<T>(options: {
    url: string;
    method: "POST" | "GET";
    body?: any;
    params?: HttpParams;
    headers?: HttpHeaders;
    responseType: XMLHttpRequestResponseType;
  }) {
    return ajax<T>({
      url: EncodeURL(options.url, options.params),
      method: options.method,
      body: options.body,
      headers: options.headers,
      responseType: options.responseType,
    }).pipe(
      switchMap((response) => {
        return of(response.response);
      })
    );
  }

  post(
    url: string,
    body: any | null,
    options: {
      params?: HttpParams;
      headers?: HttpHeaders;
      responseType: "text";
    }
  ): Observable<string>;

  post<T>(
    url: string,
    body: any | null,
    options: {
      params?: HttpParams;
      headers?: HttpHeaders;
      responseType: "json";
    }
  ): Observable<T>;

  post<T>(
    url: string,
    body: any | null,
    options: {
      params?: HttpParams;
      headers?: HttpHeaders;
      responseType: "text" | "json";
    }
  ): Observable<T> {
    return this.request({
      url,
      method: "POST",
      body,
      params: options?.params,
      headers: options?.headers,
      responseType: options.responseType,
    });
  }

  get(
    url: string,
    options: {
      params?: HttpParams;
      headers?: HttpHeaders;
      responseType: "text";
    }
  ): Observable<string>;

  get<T>(
    url: string,
    options: {
      params?: HttpParams;
      headers?: HttpHeaders;
      responseType: "json";
    }
  ): Observable<T>;

  get<T>(
    url: string,
    options: {
      params?: HttpParams;
      headers?: HttpHeaders;
      responseType: "text" | "json";
    }
  ): Observable<T> {
    return this.request({
      url,
      method: "GET",
      params: options?.params,
      headers: options?.headers,
      responseType: options.responseType,
    });
  }
}

export const http = new HttpClient();
