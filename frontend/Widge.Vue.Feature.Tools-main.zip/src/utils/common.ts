export function sleep(ms: number) {
  return new Promise<void>((resolve) => {
    setTimeout(() => {
      resolve();
    }, ms);
  });
}

export function calculateCountBetweenDates(
  begin: Date,
  end: Date,
  unit: "hours" | "days" | "months"
): number {
  const diff = end.getTime() - begin.getTime();
  const diffInUnits = Math.floor(diff / (1000 * 60 * 60 * 24));
  switch (unit) {
    case "hours":
      return diffInUnits * 24;
    case "days":
      return diffInUnits;
    case "months":
      return diffInUnits / 30;
    default:
      throw new Error("Unknown unit");
  }
}
// 把传入的数字或字符串转换成以0开头的指定位数字符串
export function zeroize(num: number | string, length: number): string {
  return `${num}`.padStart(length, "0");
}

// 计算两个时间间差距多少天小时分钟
export function countTime(start: Date, end: Date) {
  const diff = end.getTime() - start.getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return {
    days,
    hours,
    minutes,
  };
}

// 返回距离现在的时间，如：1天前，1小时前，1分钟前
export function getTimeString(date: Date): string {
  const current = new Date();
  const diff = current.getTime() - date.getTime();

  if (diff < 1000 * 60) {
    return "刚刚";
  }
  if (diff < 1000 * 60 * 60) {
    return `${Math.round(diff / (1000 * 60))}分钟前`;
  }
  if (diff < 1000 * 60 * 60 * 24) {
    return `${Math.round(diff / (1000 * 60 * 60))}小时前`;
  }
  if (diff < 1000 * 60 * 60 * 24 * 30) {
    return `${Math.round(diff / (1000 * 60 * 60 * 24))}天前`;
  }
  if (diff < 1000 * 60 * 60 * 24 * 30 * 12) {
    return `${Math.round(diff / (1000 * 60 * 60 * 24 * 30))}月前`;
  }
  return `${Math.round(diff / (1000 * 60 * 60 * 24 * 30 * 12))}年前`;
}

// 随机生成指定范围内的日期
export function randomDate(start: Date, end: Date): Date {
  return new Date(
    start.getTime() + Math.random() * (end.getTime() - start.getTime())
  );
}

// 随机中国行政区划代码
export function randomRegionCode(): string {
  const province = Math.floor(Math.random() * 34);
  const city = Math.floor(Math.random() * 31);
  const county = Math.floor(Math.random() * 30);
  return `${province}${city}${county}`;
}

// 随机生成身份证号码
export function randomIdCard(): string {
  // 随机生成出生日期
  const brith = randomDate(new Date(1949, 0, 1), new Date(2000, 11, 31));
  const year = brith.getFullYear();
  const month = (brith.getMonth() + 1).toString().padStart(2, "0");
  const day = brith.getDate().toString().padStart(2, "0");
  const birthDay = `[${year}-${month}-${day}]`;

  // 随机生成校验码

  return `${randomRegionCode()} ${birthDay} ${getTimeString(brith)}`;
}
