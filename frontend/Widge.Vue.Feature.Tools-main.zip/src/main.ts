import "./style.scss";
import { createApp } from "vue";
import App from "./App";
import { router } from "./routes";
import { EnvironmentInit } from "./environment";

async function application() {
  await EnvironmentInit();
  const app = createApp(App);
  app.use(router);
  app.mount("#app");
}

application().catch((error: ErrorEvent) => {
  console.warn(error.message);
});
