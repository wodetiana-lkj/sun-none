import {
  NConfigProvider,
  NDialogProvider,
  NMessageProvider,
  dateZhCN,
  zhCN,
} from "naive-ui";
import { Suspense, defineComponent } from "vue";

export default defineComponent({
  render() {
    return (
      <Suspense>
        <NConfigProvider locale={zhCN} dateLocale={dateZhCN}>
          <NDialogProvider>
            <NMessageProvider>
              <router-view />
            </NMessageProvider>
          </NDialogProvider>
        </NConfigProvider>
      </Suspense>
    );
  },
});
