import { Option } from "@/models/common.model";
import { mergeWith } from "lodash";

interface Environment {
  mode: string;
  uri: {
    graphql: string;
  };
  forge: {
    aes: string;
    rsa: string;
  };
  pattern: {
    idcard: string;
    mobile: string;
    sms: string;
  };
  dictionary: {
    gender: Option<number>[];
    nation: Option<number>[];
    marital_status: Option<number>[];
  };
}

const environment: Environment = {} as Environment;

export function EnvironmentInit() {
  return new Promise<void>((resolve, reject) => {
    Promise.all([
      fetch("/environments/environment.json").then(async (res) => {
        return (await res.json()) as Omit<Environment, "others">;
      }),
      fetch("/environments/rsa.pub").then((res) => {
        return res.text();
      }),
    ])
      .then(([env, rsa]) => {
        const local: Pick<Environment, "forge"> = {
          forge: {
            aes: env.forge.aes,
            rsa,
          },
        };
        mergeWith(environment, local, env);
        resolve();
      })
      .catch((error) => {
        reject(error);
      });
  });
}

export { environment };
