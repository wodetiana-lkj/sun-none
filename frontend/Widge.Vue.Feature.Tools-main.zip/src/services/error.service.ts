import { AjaxError } from "rxjs/ajax";

export function handleError(operation: string) {
  return (error: AjaxError | ErrorEvent) => {
    if (error instanceof AjaxError) {
      switch (error.status) {
        case 401:
          break;

        default:
          break;
      }
      throw new ErrorEvent(operation, { message: error.message });
    } else {
      throw error;
    }
  };
}
