import { catchError, map } from "rxjs";
import { HomeDto } from "@/models/home.model";
import { ResponseAPI } from "@/models/common.model";
import { handleError } from "./error.service";
import { http } from "@/utils/http-client";
import { environment } from "@/environment";

export function GetHome() {
  return http
    .get<ResponseAPI<HomeDto>>(`${environment.uri.graphql}/assets/post.json`, {
      responseType: "json",
    })
    .pipe(
      map((res) => {
        if (res.code !== 200) {
          throw new ErrorEvent("GetHome", {
            message: res.message,
          });
        }
        return res.data;
      }),
      catchError(handleError("GetHome"))
    );
}
