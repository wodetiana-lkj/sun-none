import { defineComponent } from "vue";

export default defineComponent({
  setup() {
    //
  },
  render() {
    return <p>Example</p>;
  },
});
