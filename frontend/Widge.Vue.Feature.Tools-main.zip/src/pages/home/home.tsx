import { defineComponent, ref } from "vue";
import { NButton, NGradientText, useMessage } from "naive-ui";
import classes from "./home.module.scss";
import { Subject, takeUntil } from "rxjs";
import { HomeDto } from "@/models/home.model";
import { GetHome } from "@/services/home.service";

export default defineComponent({
  setup() {
    const message = useMessage();
    const unsubscribe$ = new Subject();
    const data = ref<HomeDto>();
    const call = () => {
      GetHome()
        .pipe(takeUntil(unsubscribe$))
        .subscribe({
          next: (res) => {
            data.value = res;
            message.success("数据请求成功");
          },
          error: (error: ErrorEvent) => {
            message.warning(error.message);
          },
        });
    };
    return {
      data,
      call,
    };
  },
  render() {
    return (
      <>
        <h3>home</h3>
        <p>
          hello <span class={classes.red}>world</span>
        </p>
        <NGradientText type="error">炸了</NGradientText>
        <br />
        <NGradientText type="info">噢</NGradientText>
        <br />
        <NGradientText type="warning">注意</NGradientText>
        <br />
        <NGradientText type="success">成了</NGradientText>
        <div>
          <NButton onClick={this.call}>Request</NButton>
          <pre>{JSON.stringify(this.data, null, " ")}</pre>
        </div>
      </>
    );
  },
});
