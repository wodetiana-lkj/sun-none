export enum LoadingStatus {
  Loading = "loading", // 加载中
  Error = "error", // 加载出错
  Succeed = "succeed", // 加载成功
}

export interface Option<T = number> {
  label: string;
  value: T;
}
export interface ResponseAPI<T> {
  code: number;
  message: string;
  data: T;
}
