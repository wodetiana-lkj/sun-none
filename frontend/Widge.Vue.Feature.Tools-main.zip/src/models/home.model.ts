import { Option } from "./common.model";

export interface HomeDto {
  mode: string;
  uri: {
    graphql: string;
  };
  forge: {
    aes: string;
  };
  pattern: {
    idcard: string;
    mobile: string;
    sms: string;
  };
  dictionary: {
    gender: Option<number>[];
    nation: Option<number>[];
    marital_status: Option<number>[];
  };
}
