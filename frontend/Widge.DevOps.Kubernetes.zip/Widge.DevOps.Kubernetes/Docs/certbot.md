# Certbot

```bash
certbot certonly --manual --preferred-challenges dns
```
