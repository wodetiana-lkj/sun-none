# Nginx

## 代理案例

```conf
server {
    listen  80;
    listen  [::]:80;
    server_name  xunfei.dev.zhiliao.city;
    rewrite ^(.*) https://$server_name$1 permanent; 
}

server {
    listen  443 ssl;
    listen  [::]:443 ssl;
    server_name  xunfei.dev.zhiliao.city;

    if ($http_referer ~* "www.openurls.com.cn") {  
        return 403;  
    }

    location /api-xunfei {
        add_header 'Access-Control-Allow-Origin' '*' always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS, PUT, DELETE';
        add_header 'Access-Control-Allow-Credentials' 'true' always;
        add_header 'Access-Control-Allow-Headers' $http_access_control_request_headers;
        if ( $request_method = OPTIONS) { 
            return 200;
        }
        proxy_pass https://testfpva.xfzyzl.com/;
        ; proxy_pass https://www.xfzyzl.com/;
    }

    ssl_session_timeout 5m;
    ssl_protocols SSLv3 TLSv1 TLSv1.1 TLSv1.2;
    ssl_ciphers "HIGH:!aNULL:!MD5 or HIGH:!aNULL:!MD5:!3DES";
    ssl_dhparam /letsencrypt/dhparam.pem;
    
    ssl_certificate /letsencrypt/dev.zhiliao.city/fullchain1.pem;
    ssl_certificate_key /letsencrypt/dev.zhiliao.city/privkey1.pem;
}
```