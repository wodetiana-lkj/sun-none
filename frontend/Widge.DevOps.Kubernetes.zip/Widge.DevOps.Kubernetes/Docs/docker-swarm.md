# Docker Swarm

## 创建集群 Swarm

Swarm 集群由 管理节点 和 工作节点 组成。

### 初始化集群

执行 `docker swarm init` 命令的节点自动成为管理节点。如果你的 Docker 主机有多个网卡，拥有多个 IP，必须使用 `--advertise-addr` 指定 IP。

```sh
docker swarm init --advertise-addr 111.231.226.152
```

### 添加工作节点

```sh
docker swarm join \
    --token SWMTKN-1-49nj1cmql0jkz5s954yi3oex3nedyz0fb0xx14ie39trti4wxv-8vxv8rssmk743ojnwacrr2e7c \
    192.168.99.100:2377
```

### 查看集群

```sh
docker node ls
```

## 部署服务

使用 `docker service` 命令来单个管理 Swarm 集群中的服务。使用 `docker stack` 命令来批量管理 Swarm 集群中的服务，其中 -c 参数指定 compose 文件名。

### 新建服务

```sh
docker service create -p 80:80 --name nginx-tete dasoncheng/nginx-service

docker stack deploy -c stack.yml --with-registry-auth [name]
```

### 查看服务

```sh
docker service ls

docker stack ls

# 查看服务的容器状态
docker service ps nginx

# 查看服务的详细信息。
docker service inspect nginx
```

### 服务伸缩

```sh
docker service scale nginx=5
```

### 更新服务

```sh
docker service update \
--image nginx:alpine \
nginx
```

### 删除服务

```sh
docker service rm nginx

docker stack down [name]
```
