# Docker Compose

```bash
# 启动服务
docker-compose -f ./proxy/docker-compose.yml up -d
# 停止服务
docker-compose stop
# 删除服务
docker-compose rm
# 查看服务状态
docker-compose ps
```
