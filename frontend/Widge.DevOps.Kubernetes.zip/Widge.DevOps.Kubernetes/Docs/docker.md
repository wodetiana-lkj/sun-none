# Docker

## Dockerfile

## .dockerignore

## 构建镜像

```bash
docker build -t registry.cn-hangzhou.aliyuncs.com/dasoncheng/crawler:[镜像版本号] .
docker push registry.cn-hangzhou.aliyuncs.com/dasoncheng/crawler:[镜像版本号]
```

```bash
# 创建 net
docker network create net-database
# 创建 volume
docker volume create volume-redis
docker volume create volume-postgres
docker volume create volume-mongo
```

## 镜像仓库


## 命令

```bash
# 清除所有镜像
docker rmi `docker images -q`
```